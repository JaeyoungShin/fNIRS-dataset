This folder contains source code that is not shipped with this toolbox but has
to be downloaded additionally. Examples are source files for ICA, SSD, and SPoC,
for which we have wrapper functions.

In order to download the necessary source files, please execute the
`bbci_import_dependencies()` script.
