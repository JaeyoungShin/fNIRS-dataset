function C= procutil_covShrinkage(X)

C= clsutil_shrinkage(X');
