function score= procutil_scoreEigenvalues(dat, W, D)

score= diag(D)';
