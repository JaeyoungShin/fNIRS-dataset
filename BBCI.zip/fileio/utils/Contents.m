%This directory contains utility files for saving and loading EEG data
%
%
%FILEUTIL_CONCATMATLAB - concatenate Matlab data structures
%FILEUTIL_GETFILELIST - Retrieves a list of header/marker/EEG files.
%FILEUTIL_ISABSOLUTEPATH - Determines whether a path is absolute or relative.